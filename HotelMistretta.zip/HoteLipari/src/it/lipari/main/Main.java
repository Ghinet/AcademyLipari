package it.lipari.main;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

import it.lipari.hotel.Hotel;
import it.lipari.hotel.Room;
import it.lipari.hotel.SuiteRoom;

public class Main {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		Hotel h = new Hotel();

		for (int i = 0; i < 3; i++) {

			for (int j = 0; j < 20; j++) {
				if (j != 13 && j != 17) {
					int number = (i + 1) * 100 + j;
					Room r = Math.random() < 0.1 ? new SuiteRoom(number) : new Room(number);
					h.getRooms().add(r);
				}
			}

		}
		;

		System.out.println("Buongiorno, desidera prenotare una stanza?");

		do {
			System.out.println("Inserisca un'opzione (1: si / 2: no)");
			int i = in.nextInt();
			if (i == 1) {
				do {
					System.out.println("Preferisce:\n1: Stanza comune\n2: Suite");
					int choice = in.nextInt();
					if (choice == 1) {

						// TODO stanza comune

						ArrayList<Integer> roomsAvNo = new ArrayList<Integer>();

						System.out.println("Ecco, l'elenco delle stanze comuni disponibili:\n");
						for (Room r : h.getRooms()) {
							String type = r.getClass().getSimpleName();
							if (type.equals("Room") && r.isAvailable()) {
								System.out.println(r);
								roomsAvNo.add(r.getNumber());
							}
						}
						// TODO prosegui prenotazione stanza comune

						do {
							System.out.println("Inserisci il numero della stanza che le interessa prenotare:");
							int choice2 = in.nextInt();
							if (containsInt(roomsAvNo, choice2)) {
								System.out.println("Hai effettutato con successo la prenotazione della stanza: " + choice2);

								// TODO rendere la stanza prenotata non pi� disponibile
								int indexOfRoom = roomsAvNo.indexOf(choice2);
								roomsAvNo.remove(indexOfRoom);

								for (Room room : h.getRooms()) {
									if (room.getNumber() == choice2) {
										room.setAvailable(false);
										//System.out.println(h.getRooms().toString());
									}
								}

								break;
							} else {
								System.out.println("Opzione non valida, ripova");
							}
						} while (true);
						break;

					} else if (choice == 2) {
						// TODO Suite
						ArrayList<Integer> suitesAvNo = new ArrayList<Integer>();
						System.out.println("Ecco, l'elenco delle Suite disponibili:\n");
						for (Room r : h.getRooms()) {
							String type = r.getClass().getSimpleName();
							if (type.equals("SuiteRoom") && r.isAvailable()) {
								System.out.println(r);
								suitesAvNo.add(r.getNumber());

							}
						}

						do {
							System.out.println("Inserisci il numero della stanza che le interessa prenotare:");
							int choice2 = in.nextInt();
							if (containsInt(suitesAvNo, choice2)) {
								System.out.println("Hai effettutato con successo la prenotazione della stanza: " + choice2);

								// TODO rendere la stanza prenotata non pi� disponibile
								int indexOfRoom = suitesAvNo.indexOf(choice2);
								suitesAvNo.remove(indexOfRoom);
								
								for (Room room : h.getRooms()) {
									if (room.getNumber() == choice2) {
										room.setAvailable(false);
										//System.out.println(h.getRooms().toString());
									}
								}
								// TODO prosegui prenotazione
								break;
							} else {
								System.out.println("Opzione non valida, ripova");
							}
						} while (true);

						break;
					} else {
						System.out.println("Opzione non valida, riprova");
					}
				} while (true);

				break;
			} else if (i == 2) {
				System.out.println("Non c'� problema,\nBuonagiornata!");
				break;
			} else {
				System.out.println("Opzione non valida, riprovi");
			}
		} while (true);

	}

	public static boolean containsInt(final ArrayList<Integer> roomsAvNo, final int number) {
		return roomsAvNo.stream().anyMatch(o -> o == number);
	}

}
