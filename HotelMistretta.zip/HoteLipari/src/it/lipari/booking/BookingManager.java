package it.lipari.booking;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import it.lipari.hotel.Room;

public class BookingManager {
	
	HashMap<String,ArrayList<Booking>> bookingsPerClient = new HashMap<String,ArrayList<Booking>>();
	HashMap<Integer,HashMap<Date,Booking>> bookingsPerRoomNumber = new HashMap<Integer,HashMap<Date,Booking>>();
	
	public void addBooking(Booking b) {
	
		ArrayList<Booking> list = bookingsPerClient.get(b.getClientEmail());
		if(list == null) {
			list = new ArrayList<Booking>();
		}
		list.add(b);
		bookingsPerClient.put(b.getClientEmail(), list);
		
		Room r = b.getRoom();
		Integer rn = r.getNumber();
		HashMap<Date,Booking> bookingsPerDate = bookingsPerRoomNumber.get(rn);
		if(bookingsPerDate == null) {
			bookingsPerDate = new HashMap<Date,Booking>();
		}
		bookingsPerDate.put(b.getDate(), b);
		bookingsPerRoomNumber.put(rn, bookingsPerDate);
	}

}
