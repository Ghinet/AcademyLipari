package clacolatriceScientifica;

public class operatori {

	public double somma(double a, double b) {
		return a + b;
	}
	
	public double sottrazione(double a, double b) {
		return a - b;
	}
	
	public double moltiplicazione(double a, double b) {
		return a * b;
	}
	
	public double divisione(double a, double b) {
		return a / b;
	}
	public double resto(double a, double b) {
		return a % b;
	}
	
	public double[] radice(double a, double b) {
		double[] result = new double[2];
		result[0] = Math.sqrt(a);
		result[1] = Math.sqrt(b);
		return result;
	}
	
	public double esponente(double a, double b) {
		int x = (int)a;
		int y = (int)(b);
		for(int i=1; i<y; i++) {
			a = a * x;
		}
		return a;
	}
	
	

}
