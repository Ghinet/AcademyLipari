package clacolatriceScientifica;

import java.util.Scanner;

public class Calcolatrice {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		operatori c = new operatori();
		
		System.out.println("Calcoltrice Scientifica o quasi...");
		int stopRepeat = 2; //inizializzo  per la condizione while
		
		while(stopRepeat == 2){
			System.out.println("\nScelga dal men� sottostante l'operazione che preferisce eseguire\n"
					+ "ed inserisca il numero corrispettivo seguito dal tasto invio;\n"
					+ "1. Somma dei due numeri;\n"
					+ "2. Sottrazione dei due numeri;\n"
					+ "3. Moltiplicazione dei due numeri;\n"
					+ "4. Divisione del primo per il secondo numero;\n"
					+ "5. Il primo numero con il secondo a esponente;\n"
					+ "6. Radice sia del primo che del secondo numero;\n");
			
			int option = Integer.parseInt(scanner.nextLine());
						
			System.out.println("Inserire i due numeri con cui si vorr� eseguire una o pi� operazioni,\n"
					+ "seguiti dal tasto invio;\n"
					+ "Primo numero: ");
			
			double a = Double.parseDouble(scanner.nextLine());
			System.out.println("Secondo numero: ");	
			
			double b = Double.parseDouble(scanner.nextLine());
			
			
		
			switch(option) {
				case 1:
					System.out.println("Il risultato �: " + c.somma(a, b));
					break;
				case 2:
					System.out.println("Il risultato �: " + c.sottrazione(a, b));
					break;
				case 3:
					System.out.println("Il risultato �: " + c.moltiplicazione(a, b));
					break;
				case 4:
					if (b != 0) {
						System.out.println("Il risultato �: " + c.divisione(a, b));
						
						if(c.resto(a, b) != 0) {
							System.out.println("e il resto �: " + c.resto(a, b));
						}
					}else {
						System.out.println("Non pu� dividere un numero per 0.");
					}
					break;
				case 5:
					System.out.println("Il risultato di " + a + "^" + b + " �: " + c.esponente(a, b));
					break;
				case 6:
					double[] result = c.radice(a, b);
					System.out.println("I risultati corrispettivi sono: " + result[0] + " e " + result[1]  );
					break;
				default:
					System.out.println("Opzione non valida");
			}
			System.out.println("Desidera fare altre operazioni? (1. no; 2. si)");
			stopRepeat = Integer.parseInt(scanner.nextLine());
			
		}
	}

}
